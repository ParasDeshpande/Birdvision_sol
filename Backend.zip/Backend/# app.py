# app.py
from flask import Flask, request, jsonify
from flask_sqlalchemy import SQLAlchemy
from flask_jwt_extended import JWTManager, jwt_required, create_access_token

app = Flask(__name__)
app.config["SQLALCHEMY_DATABASE_URI"] = "sqlite:///products.db"
app.config["JWT_SECRET_KEY"] = "secret-key"
db = SQLAlchemy(app)
jwt = JWTManager(app)

class Product(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    title = db.Column(db.String(100), nullable=False)
    description = db.Column(db.String(200), nullable=False)
    price = db.Column(db.Float, nullable=False)

@app.route("/products", methods=["GET"])
@jwt_required
def get_all_products():
    limit = int(request.args.get("limit", 10))
    skip = int(request.args.get("skip", 0))
    products = Product.query.limit(limit).offset(skip).all()
    return jsonify([{"id": p.id, "title": p.title, "description": p.description, "price": p.price} for p in products])

@app.route("/products/<int:id>", methods=["GET"])
@jwt_required
def get_product(id):
    product = Product.query.get(id)
    if product is None:
        return jsonify({"error": "Product not found"}), 404
    return jsonify({"id": product.id, "title": product.title, "description": product.description, "price": product.price})

@app.route("/products", methods=["POST"])
@jwt_required
def create_product():
    data = request.get_json()
    if not data:
        return jsonify({"error": "Invalid request"}), 400
    try:
        product = Product(title=data["title"], description=data["description"], price=data["price"])
        db.session.add(product)
        db.session.commit()
        return jsonify({"id": product.id, "title": product.title, "description": product.description, "price": product.price}), 201
    except Exception as e:
        return jsonify({"error": str(e)}), 500

@app.route("/products/<int:id>", methods=["PUT"])
@jwt_required
def update_product(id):
    product = Product.query.get(id)
    if product is None:
        return jsonify({"error": "Product not found"}), 404
    data = request.get_json()
    if not data:
        return jsonify({"error": "Invalid request"}), 400
    try:
        product.title = data["title"]
        product.description = data["description"]
        product.price = data["price"]
        db.session.commit()
        return jsonify({"id": product.id, "title": product.title, "description": product.description, "price": product.price})
    except Exception as e:
        return jsonify({"error": str(e)}), 500

@app.route("/products/<int:id>", methods=["DELETE"])
@jwt_required
def delete_product(id):
    product = Product.query.get(id)
    if product is None:
        return jsonify({"error": "Product not found"}), 404
    try:
        db.session.delete(product)
        db.session.commit()
        return jsonify({"message": "Product deleted"})
    except Exception as e:
        return jsonify({"error": str(e)}), 500

@app.route("/login", methods=["POST"])
def login():
    username = request.json.get("username")
    password = request.json.get("password")
    if username!= "admin" or password!= "password":
        return jsonify({"error": "Invalid credentials"}), 401
    access_token = create_access_token(identity=username)
    return jsonify({"access_token": access_token})

if __name__ == "__main__":
    app.run(debug=True)